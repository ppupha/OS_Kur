+-------------------------------------------------------------------+
| THE OLD FILE SYSTEM OF MY OLD ENGINE                              |
+-------------------------------------------------------------------+
| Although this is rather a messy piece of code, it's still         |
| (c) 2001 Michael Walter                                           |
| ;-)                                                               |
+-------------------------------------------------------------------+
| As long as you have fun with it, use it in your engine (or better |
| use the VFS I'm designing for a tutorial series on flipcode.com). |
| A small note like "VFS by Michael Walter (michiwalter@gmx.de)"    |
| would be appreciated but not necessary ;-)                        |
|                                                                   |
| Tutorial URL:  http://www.flipcode.com/tutorials/tut_vfs01.shtml  |
+-------------------------------------------------------------------+
| Have fun ;-)                                                      |
+-------------------------------------------------------------------+

+-------------------------------------------------------------------+
| CONTENTS                                                          |
+-------------------------------------------------------------------+
| pak.cpp		The PAKing program that either creates or   |
|			or extracts PAK files (the predecessors of  |
|			the VFS archive files).                     |
+-------------------------------------------------------------------+