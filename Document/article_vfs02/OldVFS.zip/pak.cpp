//****************************************************************************
//**
//**    PAK.CPP
//**    PAK
//**
//**    Syntax:
//**      pak {--create|--extract} path
//**
//**      --create:  create an archive out of the subdir path.
//**      --extract: extract the archive path.
//****************************************************************************

//============================================================================
//    IMPLEMENTATION HEADERS
//============================================================================
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <direct.h>
#include <io.h>

//============================================================================
//    IMPLEMENTATION PRIVATE DEFINITIONS / ENUMERATIONS / SIMPLE TYPEDEFS
//============================================================================
#define PAK_MAGIC	' KAP'
#define PAK_VERSION	0x0200

enum
{ ACTION_CREATE, ACTION_EXTRACT, ACTION_SYNTAX };

enum
{ ENTRY_TYPE_SUBDIR=0, ENTRY_TYPE_FILE };

//============================================================================
//    IMPLEMENTATION PRIVATE CLASS PROTOTYPES / EXTERNAL CLASS REFERENCES
//============================================================================
//============================================================================
//    IMPLEMENTATION PRIVATE STRUCTURES / UTILITY CLASSES
//============================================================================
#define PAK_HEADER_SIZE		(4*sizeof(int))
#define PAK_ENTRY_SIZE		(4*sizeof(int)+1024*sizeof(char))

typedef unsigned long dword;

struct pakHeader_t
{
	dword magic;
	dword version;
	dword numEntries;
	dword totalBytes;

	// impl.
	struct pakEntry_t* first;
	// end impl.
};

struct pakEntry_t
{
	int type;
	char name[1024];

	dword offset; // for file.
	dword size;

	dword numEntries; // for subdir.

	// impl.
	char* buffer;
	pakEntry_t* next;
	// end impl.
};

//============================================================================
//    IMPLEMENTATION REQUIRED EXTERNAL REFERENCES (AVOID)
//============================================================================
//============================================================================
//    IMPLEMENTATION PRIVATE DATA
//============================================================================
static int action;
static char target[_MAX_PATH];

//============================================================================
//    INTERFACE DATA
//============================================================================
//============================================================================
//    IMPLEMENTATION PRIVATE FUNCTION PROTOTYPES
//============================================================================
static void ParseCmdLine(int argc, char** argv);
static bool ExistsDir(const char* dir);
static bool ExistsFile(const char* file);
static void ActionSyntax();
static void ActionCreate();
static pakEntry_t* Iterate(const char* dir, pakHeader_t* header, pakEntry_t* cur);
static void CalculateOffsets(pakHeader_t* header);
static void WritePak(const char* pakFile, pakHeader_t* header);
static void FreePak(pakHeader_t* header);
static void ActionExtract();
static pakHeader_t* ParsePakFile(const char* pakFile);
static pakEntry_t* ProcessDir(pakEntry_t* cur, pakHeader_t* header, bool root=true);

//============================================================================
//    IMPLEMENTATION PRIVATE FUNCTIONS
//============================================================================
static void ParseCmdLine(int argc, char** argv)
{
	// init target.
	strcpy(target, "");

	// missing params.
	if(argc<3)
	{
		action=ACTION_SYNTAX;
		return;
	}

	// create archive?
	if(stricmp(argv[1], "--create")==0)
	{
		action=ACTION_CREATE;
		strcpy(target, argv[2]);
		return;
	}

	// extract archive?
	if(stricmp(argv[1], "--extract")==0)
	{
		action=ACTION_EXTRACT;
		strcpy(target, argv[2]);
		return;
	}

	action=ACTION_SYNTAX;
}

static bool ExistsDir(const char* dir)
{
	static char buffer[_MAX_PATH];
	getcwd(buffer, _MAX_PATH);
	bool exists=chdir(dir)==0;
	chdir(buffer);
	return exists;
}

static bool ExistsFile(const char* file)
{
	FILE* f=fopen(file, "rb");
	bool exists=f!=NULL;
	if(f)
		fclose(f);
	return exists;
}

static void ActionSyntax()
{
	// print syntax.
	printf("pak --create|--extract path\n"
		"\n"
		"--create:  create a new pak archive path.pak out of the subdir path.\n"
		"--extract: extract the archive path.pak.\n");
}

static void ActionCreate()
{
	static char pakFile[_MAX_PATH];

	// check for existance of directory.
	if(!ExistsDir(target))
	{
		printf("pak: directory %s not found.\n", target);
		exit(1);
	}

	// create pak file name.
	strcpy(pakFile, target);
	strcat(pakFile, ".pak");

	// compose header.
	pakHeader_t* header=new pakHeader_t;
	header->magic=PAK_MAGIC;
	header->version=PAK_VERSION;
	header->numEntries=0;
	header->totalBytes=PAK_HEADER_SIZE;
	header->first=0;

	// iterate dir with subdirs.
	pakEntry_t* first=Iterate(target, header, 0);

	// calculate offsets.
	CalculateOffsets(header);

	// write pak file.
	WritePak(pakFile, header);

	// status.
	printf("\ncreated %s (%i entries, %i bytes)\n", pakFile, header->numEntries, header->totalBytes);

	// free pak structure.
	FreePak(header);
}

static pakEntry_t* Iterate(const char* dir, pakHeader_t* header, pakEntry_t* cur)
{
	// search pattern.
	char buffer[1024];
	strcpy(buffer, dir);
	strcat(buffer, "\\*.*");

	// this pointer.
	pakEntry_t* t=cur;

	// dir contents...
	_finddata_t fd;
	int handle=_findfirst(buffer, &fd);
	if(handle==-1)
		return t;

	// for each entry.
	do
	{
		if(strcmp(fd.name, ".")==0 || strcmp(fd.name, "..")==0)
			continue;

		// new entry.
		if(t)
			t->numEntries++;
		header->numEntries++;
		printf(".");

		// entry structure.
		pakEntry_t* entry=new pakEntry_t;
		memset(entry, 0, sizeof(pakEntry_t));
		strcpy(entry->name, fd.name);
		if(cur)
			cur->next=entry;
		cur=entry;

		if(!header->first)
			header->first=entry;

		// create more-or-less full filenamename.
		strcpy(buffer, dir);
		strcat(buffer, "\\");
		strcat(buffer, fd.name);

		header->totalBytes+=PAK_ENTRY_SIZE;

		// dir?
		if(fd.attrib&_A_SUBDIR)
		{
			// set entry.
			entry->type=ENTRY_TYPE_SUBDIR;

			// iterate.
			cur=Iterate(buffer, header, cur);
		}
		else
		{
			// setentry.
			entry->type=ENTRY_TYPE_FILE;
			entry->size=fd.size;

			if(fd.size)
			{
				// load data into buffer.
				char* data=new char[fd.size];
				FILE* f=fopen(buffer, "rb");
				if(fread(data, 1, fd.size, f)!=fd.size)
				{
					printf("fread(%s) failed.\n", buffer);
				}
				entry->buffer=data;
				fclose(f);
			}
			header->totalBytes+=fd.size;
		}
	}
	while(_findnext(handle,	&fd)!=-1);

	return cur;
}

static void CalculateOffsets(pakHeader_t* header)
{
	int n=0;
	pakEntry_t* entry=header->first;
	while(entry)
	{
		entry->offset=PAK_HEADER_SIZE+PAK_ENTRY_SIZE*header->numEntries+n;
		n+=entry->size;
		entry=entry->next;
	}
}

static void WritePak(const char* pakFile, pakHeader_t* header)
{
	// open file.
	FILE* f=fopen(pakFile, "wb");
	if(!f)
	{
		printf("pak: pak file %s couldn't be created.", pakFile);
		exit(1);
	}

	// write header.
	if(fwrite(header, 1, PAK_HEADER_SIZE, f)!=PAK_HEADER_SIZE)
	{
		printf("pak: write(header) failed.");
		exit(1);
	}

	// write entries...
	pakEntry_t* entry=header->first;
	while(entry)
	{
		if(fwrite(entry, 1, PAK_ENTRY_SIZE, f)!=PAK_ENTRY_SIZE)
		{
			printf("pak: write(entry) failed.");
			exit(1);
		}
		entry=entry->next;
	}

	// write data...
	entry=header->first;
	while(entry)
	{
		printf(".");

		if(!entry->buffer && !entry->size)
		{
			entry=entry->next;
			continue;
		}

		if(fwrite(entry->buffer, 1, entry->size, f)!=entry->size)
		{
			printf("pak: write(data) failed.");
			exit(1);
		}

		entry=entry->next;
	}
}

static void FreePak(pakHeader_t* header)
{
	pakEntry_t* entry=header->first;
	while(entry)
	{
		if(entry->buffer && entry->size)
		{
			delete[] entry->buffer;
		}

		pakEntry_t* next=entry->next;
		delete entry;
		entry=next;
	}

	delete header;
}

static void ActionExtract()
{
	static char pakFile[_MAX_PATH];

	// create pak file name.
	strcpy(pakFile, target);
	if(strcmp(pakFile+strlen(pakFile)-4, ".pak")!=0)
		strcat(pakFile, ".pak");

	// check for existance of pak file.
	if(!ExistsFile(pakFile))
	{
		printf("pak: pak file %s not found.\n", pakFile);
		exit(1);
	}

	// check for non-existance of directory.
	if(ExistsDir(target))
	{
		printf("pak: directory %s already exists.\n", target);
		exit(1);
	}

	pakHeader_t* header=ParsePakFile(pakFile);

	// create directory.
	if(_mkdir(target)==-1)
	{
		printf("pak: couldn't create directory %s.\n", target);
		exit(1);
	}

	// change dir.
	chdir(target);

	// create dir structure.
	ProcessDir(header->first, header);

	// change dir.
	chdir("..");

	// status.
	printf("\nextracted %s (%i entries, %i bytes)\n", pakFile, header->numEntries, header->totalBytes);

	// free data.
	FreePak(header);
}

static pakHeader_t* ParsePakFile(const char* pakFile)
{
	// open pak file.
	FILE* f=fopen(pakFile, "rb");

	// parse header.
	pakHeader_t* header=new pakHeader_t;
	memset(header, 0, sizeof(pakHeader_t));
	if(fread(header, 1, PAK_HEADER_SIZE, f)!=PAK_HEADER_SIZE)
	{
		printf("pak: fread(header) failed.\n");
		exit(1);
	}
	if(header->magic!=PAK_MAGIC)
	{
		printf("pak: %s is not a valid pak file.\n", pakFile);
		exit(1);
	}
	if(header->version!=PAK_VERSION)
	{
		printf("pak: bad pak version. %x expected, %x found.", PAK_VERSION, header->version);
		exit(1);
	}

	// parse pak file.
	pakEntry_t* cur=0;
	for(int i=0; i<header->numEntries; i++)
	{
		printf(".");

		pakEntry_t* entry=new pakEntry_t;
		memset(entry, 0, sizeof(pakEntry_t));
		if(fread(entry, 1, PAK_ENTRY_SIZE, f)!=PAK_ENTRY_SIZE)
		{
			printf("pak: fread(entry) failed.\n");
			exit(1);
		}

		if(cur)
			cur->next=entry;
		cur=entry;

		if(!header->first)
			header->first=entry;

		// if it is a file and if it contains data...
		if(entry->type==ENTRY_TYPE_FILE && entry->size!=0)
		{
			// store current position.
			int cur=ftell(f);

			// jump to data offset.
			fseek(f, entry->offset, SEEK_SET);

			// reserve memroy.
			entry->buffer=new char[entry->size];

			// read data.
			int n;
			if((n=fread(entry->buffer, 1, entry->size, f))!=entry->size)
			{
				printf("pak: fread(data) failed.\n");
				exit(1);
			}

			// jump back to stored position.
			fseek(f, cur, SEEK_SET);
		}
	}

	// close pak file.
	fclose(f);

	return header;
}

static pakEntry_t* ProcessDir(pakEntry_t* cur, pakHeader_t* header, bool root)
{
	// number of entries if directory...
	bool subDir=cur->type==ENTRY_TYPE_SUBDIR;
	int numEntries=-1;

	// next entry if subdir...
	if(!root && subDir)
	{
		numEntries=cur->numEntries;
		cur=cur->next;
	}

	while(cur)
	{
		printf(".");
		if(!root && subDir && numEntries--<=0)
			break;

		// dir?
		if(cur->type==ENTRY_TYPE_SUBDIR)
		{
			// make and go to subdir.
			mkdir(cur->name);
			chdir(cur->name);

			// process sub dir.
			cur=ProcessDir(cur, header, false);

			// go back.
			chdir("..");
		}
		else
		{
			// create file...
			FILE* f=fopen(cur->name, "wb");

			if(cur->buffer && cur->size)
			{
				// write data...
				if(fwrite(cur->buffer, 1, cur->size, f)!=cur->size)
				{
					printf("pak: fwrite(%s) failed.\n", cur->name);
					exit(1);
				}
			}

			fclose(f);
		}

		cur=cur->next;
	}

	return cur;
}

int main(int argc, char** argv)
{
	// parse command line.
	ParseCmdLine(argc, argv);

	// do the action...
	switch(action)
	{
	case ACTION_SYNTAX:
		ActionSyntax();
		break;
	case ACTION_CREATE:
		ActionCreate();
		break;
	case ACTION_EXTRACT:
		ActionExtract();
		break;
	default:
		printf("internal error: main(): bad action %i.\n", action);
		exit(1);
		break;
	}

	return 0;
}

//============================================================================
//    INTERFACE FUNCTIONS
//============================================================================
//============================================================================
//    INTERFACE CLASS BODIES
//============================================================================